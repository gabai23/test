/**
 * 
 */
/**
 * @author inouetakuma
 *
 */
package com.internousdev.sampleweb.dto;